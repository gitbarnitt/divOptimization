#' Simulate baseline and perturbed datasets using posterior draws
#' 
#' @param fit_result List from fit_gjam_model_test() with $fit, $xdata, $ydata
#' @param year_baseline Character: year for baseline condition (e.g., "2015")
#' @param year_perturbed Character: year for perturbed condition (e.g., "2016")
#' @param effect Numeric: relative perturbation applied to perturbed-year mean (0.20 = +20%)
#' @param noise_mode Character: "mu_only" (latent mean only) or "sigma" (add residual noise)
#' @param seed Integer: random seed for reproducibility
#' @param n_draws Integer: how many posterior draws to use (NULL = all)
#' 
#' @details
#' Perturbation logic: mu_perturbed = mu_changed_year * (1 + effect)
#'   - This applies the effect relative to the perturbed year's natural mean
#'   - Effect is multiplicative on the latent scale (before observation noise)
#' 
#' Noise modes:
#'   - "mu_only": Returns pure latent means (will overestimate power / underestimate N*)
#'   - "sigma": Adds residual noise using Σ from posterior (realistic uncertainty)
#' 
#' @return List with:
#'   - y_base_sim: [n_draws, n_plots, n_species] baseline predictions
#'   - y_pert_sim: [n_draws, n_plots, n_species] perturbed predictions
#'   - plot_ids: character vector of plot IDs
#'   - meta: list(effect, seed, years, n_draws, noise_mode)
simulate_perturbed_dataset <- function(
    fit_result,
    year_baseline,
    year_perturbed,
    effect = 0.20,
    noise_mode = c("sigma", "mu_only"),
    seed = NULL,
    n_draws = NULL
) {
  if (!is.null(seed)) set.seed(seed)
  noise_mode <- match.arg(noise_mode)
  
  fit <- fit_result$fit
  xdata <- fit_result$xdata
  
  # Validate years exist in factor levels
  year_levels <- levels(xdata$year)
  if (!year_baseline %in% year_levels) {
    stop(sprintf("year_baseline '%s' not in model levels: %s", 
                 year_baseline, paste(year_levels, collapse = ", ")))
  }
  if (!year_perturbed %in% year_levels) {
    stop(sprintf("year_perturbed '%s' not in model levels: %s", 
                 year_perturbed, paste(year_levels, collapse = ", ")))
  }
  
  # Get plots sampled in BOTH baseline and perturbed years
  # This ensures we only use plots that could actually contribute to the year-pair comparison
  plots_baseline <- xdata %>%
    dplyr::filter(year == year_baseline) %>%
    dplyr::distinct(plotID)
  
  plots_perturbed <- xdata %>%
    dplyr::filter(year == year_perturbed) %>%
    dplyr::distinct(plotID)
  
  eligible_plots <- dplyr::inner_join(plots_baseline, plots_perturbed, by = "plotID")
  
  n_base_only <- nrow(plots_baseline) - nrow(eligible_plots)
  n_pert_only <- nrow(plots_perturbed) - nrow(eligible_plots)
  
  if (nrow(eligible_plots) == 0) {
    stop(sprintf(
      "No plots sampled in both %s (n=%d) and %s (n=%d)",
      year_baseline, nrow(plots_baseline),
      year_perturbed, nrow(plots_perturbed)
    ))
  }
  
  if (n_base_only > 0 || n_pert_only > 0) {
    message(sprintf(
      "[TierP0] Restricting to %d plots sampled in both years (excluded: %d baseline-only, %d perturbed-only)",
      nrow(eligible_plots), n_base_only, n_pert_only
    ))
  }
  
  # Filter xdata to eligible plots only
  xdata <- xdata %>%
    dplyr::semi_join(eligible_plots, by = "plotID")
  
  # Validate nlcdClass is constant per plot
  bad_plots <- xdata %>%
    dplyr::count(plotID, nlcdClass) %>%
    dplyr::count(plotID) %>%
    dplyr::filter(n > 1)
  
  if (nrow(bad_plots) > 0) {
    stop(sprintf(
      "nlcdClass varies within plotID for %d plots; cannot build plot-level invariants safely. Check plots: %s",
      nrow(bad_plots),
      paste(head(bad_plots$plotID), collapse = ", ")
    ))
  }
  
  # Build deterministic plot-level covariates from eligible plots
  plot_covariates <- xdata %>%
    dplyr::group_by(plotID) %>%
    dplyr::summarise(
      nlcdClass = dplyr::first(nlcdClass),  # Validated constant above
      .groups = "drop"
    ) %>%
    dplyr::arrange(plotID)  # Deterministic ordering
  
  n_plots <- nrow(plot_covariates)
  
  message(sprintf(
    "[TierP0] Simulating %s → %s with +%.0f%% effect on %d plots (noise_mode=%s)",
    year_baseline, year_perturbed, effect * 100, n_plots, noise_mode
  ))
  
  # Create design rows for baseline year
  xnew_base <- plot_covariates %>%
    dplyr::mutate(
      year = factor(year_baseline, levels = year_levels),
      nlcdClass = factor(nlcdClass, levels = levels(xdata$nlcdClass))
    )
  
  # Perturbed year (same plots, different year)
  xnew_pert <- plot_covariates %>%
    dplyr::mutate(
      year = factor(year_perturbed, levels = year_levels),
      nlcdClass = factor(nlcdClass, levels = levels(xdata$nlcdClass))
    )
  
  # Get posterior predictions based on noise mode
  if (noise_mode == "sigma") {
    # Use observation-level predictions with residual noise
    mu_base <- manual_posterior_predict_obs(
      fit = fit,
      xnew = xnew_base,
      seed = if (!is.null(seed)) seed + 1 else NULL
    )  # [draws, plots, species]
    
    mu_pert_base <- manual_posterior_predict_obs(
      fit = fit,
      xnew = xnew_pert,
      seed = if (!is.null(seed)) seed + 2 else NULL
    )
    
  } else {
    # Use latent means only (no observation noise)
    mu_base <- manual_posterior_predict(fit, xnew_base)  # [draws, plots, species]
    mu_pert_base <- manual_posterior_predict(fit, xnew_pert)
  }
  
  # Apply perturbation to perturbed year
  # Interpretation: "What if the perturbed year had a +20% effect relative to its natural state?"
  mu_pert <- mu_pert_base * (1 + effect)
  
  # Subset draws if requested
  if (!is.null(n_draws)) {
    total_draws <- dim(mu_base)[1]
    idx <- sample.int(total_draws, size = min(n_draws, total_draws), replace = FALSE)
    mu_base <- mu_base[idx, , , drop = FALSE]
    mu_pert <- mu_pert[idx, , , drop = FALSE]
  }
  
  # Return simulated datasets
  list(
    y_base_sim = mu_base,  # [draws, plots, species]
    y_pert_sim = mu_pert,  # [draws, plots, species]
    plot_ids = plot_covariates$plotID,
    meta = list(
      effect = effect,
      seed = seed,
      year_baseline = year_baseline,
      year_perturbed = year_perturbed,
      noise_mode = noise_mode,
      n_draws = dim(mu_base)[1],
      n_plots = n_plots
    )
  )
}
