


load_neon_data <- function(path) {
  raw <- readRDS(path)
  
  # Filter to specific site if SITE_ID env var is set (for MULTISITE mode)
  site_filter <- Sys.getenv("SITE_ID", "")
  if (site_filter != "") {
    message("Filtering data to site: ", site_filter)
    if (!"siteID" %in% names(raw)) {
      stop("SITE_ID filter requested but data has no 'siteID' column")
    }
    raw <- raw %>% dplyr::filter(siteID == site_filter)
    if (nrow(raw) == 0) {
      stop("No data found for SITE_ID: ", site_filter)
    }
    message("  Retained ", nrow(raw), " rows for ", site_filter)
  }
  
  filtered <- raw %>%
    dplyr::select(siteID, plotID, year, boutNumber, taxonID, nlcdClass,
                  subplotID, percentCover, samplingImpractical, targetTaxaPresent) %>%
    dplyr::filter(targetTaxaPresent == "Y") %>%
    dplyr::mutate(year = as.integer(year)) %>%
    dplyr::filter(is.na(samplingImpractical) | samplingImpractical == "OK") %>%
    dplyr::mutate(
      n_subplots_expected = dplyr::if_else(year <= 2018L, 8L, 6L),
      percentCover = tidyr::replace_na(percentCover, 0)
    )
  
  # Per-bout sums and sums of squares over observed subplots
  bout_agg <- filtered %>%
    dplyr::group_by(siteID, plotID, year, boutNumber, taxonID, nlcdClass, n_subplots_expected) %>%
    dplyr::summarise(
      sum_cover   = sum(percentCover, na.rm = TRUE),
      sum_sq      = sum(percentCover * percentCover, na.rm = TRUE),
      n_obs       = dplyr::n(),                # observed subplots
      .groups     = "drop"
    )
  
  # Mean/SD over expected subplots *including zeros for missing*
  # mean = sum / Nexp
  # var  = (sum_sq / Nexp) - mean^2   (zeros contribute 0 to sum_sq)
  per_bout_summary <- bout_agg %>%
    dplyr::mutate(
      n_subplots = n_subplots_expected,
      mean_cover = sum_cover / n_subplots_expected,
      var_cover  = (sum_sq / n_subplots_expected) - (mean_cover * mean_cover),
      sd_cover   = sqrt(pmax(var_cover, 0))
    ) %>%
    dplyr::select(siteID, plotID, year, boutNumber, taxonID, nlcdClass,
                  mean_cover, sd_cover, n_subplots)
  
  # Average across bouts (your previous behavior)
  final_summary <- per_bout_summary %>%
    dplyr::group_by(siteID, plotID, year, taxonID, nlcdClass) %>%
    dplyr::summarise(
      mean_cover = mean(mean_cover, na.rm = TRUE),
      sd_cover   = mean(sd_cover,  na.rm = TRUE),
      n_subplots = sum(n_subplots, na.rm = TRUE),
      n_bouts    = dplyr::n_distinct(boutNumber),
      .groups    = "drop"
    )
  
  final_summary
}
