
library(targets)
source("R/load_neon_data.R")
source("R/fit_gjam_model.R")
source("R/simulate_change.R")
source("R/estimate_detection_prob.R")
source("R/plot_detection_prob.R")
source("R/plot_subsampling.R")

tar_option_set(packages = c("dplyr", "tidyr", "gjam", "purrr", "ggplot2"))

list(
  tar_target(neon_data, load_neon_data("data/plant_data.rds")),
  tar_target(site_subsamples, split(neon_data, neon_data$siteID)),
  tar_target(gjam_fits, lapply(site_subsamples, fit_gjam_model)),
  tar_target(simulated_fits, lapply(gjam_fits, simulate_change)),
  tar_target(detection_summary, estimate_detection_prob(simulated_fits)),
  tar_target(report, {
    output_file <- "outputs/detection_report.html"
    rmarkdown::render("detection_report.Rmd", output_file = output_file, quiet = TRUE)
    output_file
  }, format = "file")
)
